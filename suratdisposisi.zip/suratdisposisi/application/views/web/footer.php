<!-- Footer -->
<div class="footer text-muted text-center">
	<a href="" class="text-danger"><b>SIS ADMINISTRASI-SMPN 2 Kedawung Sragen</b></a> &copy; 2023fajarveraningsih
</div>
<!-- /footer -->
</div>
<!-- /content area -->
</div>
<!-- /main content -->
</div>
<!-- /page content -->
</div>
<!-- /page container -->
</body>

</html>